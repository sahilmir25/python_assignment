# Lambda function with a student dictionary
# Key = roll number, value = student details

students = {
    1: {"name": "Amit", "dept": "CSE", "marks": 85},
    2: {"name": "Riya", "dept": "CSE", "marks": 92},
    3: {"name": "Rahul", "dept": "CSE", "marks": 76},
    4: {"name": "Suman", "dept": "CSE", "marks": 88},
    5: {"name": "Priya", "dept": "CSE", "marks": 95}
}

# i) Sort according to marks (highest to lowest)
sorted_students = sorted(
    students.items(),
    key=lambda item: item[1]["marks"],
    reverse=True
)

print("Students sorted by marks (highest to lowest):")
for roll, details in sorted_students:
    print(roll, details)

# ii) Print student with maximum marks
top_student = max(students.items(), key=lambda item: item[1]["marks"])
print("\nStudent with maximum marks:")
print(top_student)

# iii) Average marks
average = sum(map(lambda item: item[1]["marks"], students.items())) / len(students)
print("\nAverage marks =", average)
