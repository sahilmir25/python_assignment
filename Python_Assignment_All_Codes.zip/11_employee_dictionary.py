# Employee dictionary
employees = {
    "E101": {"name": "Amit", "department": "IT", "salary": 50000},
    "E102": {"name": "Rahul", "department": "HR", "salary": 45000},
    "E103": {"name": "Priya", "department": "Finance", "salary": 55000},
    "E104": {"name": "Suman", "department": "IT", "salary": 60000},
    "E105": {"name": "Riya", "department": "Sales", "salary": 48000}
}

for emp_id, details in employees.items():
    print(emp_id, ":", details)

name = input("Enter employee name to search: ")

found = False
for emp_id, details in employees.items():
    if details["name"].lower() == name.lower():
        print("Employee found:", emp_id, details)
        found = True

if not found:
    print("Employee not found")
