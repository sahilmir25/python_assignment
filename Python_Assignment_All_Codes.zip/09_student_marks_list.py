# Student marks list
marks = [50, 60, 70, 80, 85, 60, 90, 95, 65, 55]

print("Marks:", marks)
print("Maximum marks:", max(marks))
print("Minimum marks:", min(marks))
print("Average marks:", sum(marks) / len(marks))

above_80 = [m for m in marks if m > 80]
print("Marks above 80:", above_80)
