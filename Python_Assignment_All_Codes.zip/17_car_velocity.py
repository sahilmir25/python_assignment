# Q3. Two cars:
# They move in the same direction and meet after 3 hours.
# If they move in opposite directions, they meet after 1 hour.
# Find the velocity of both cars.

# Let velocities be u and v.
# Same direction: distance difference = 3(u-v)
# Opposite direction: distance sum = 1(u+v)
# Therefore: 3(u-v) = u+v

# This gives only the velocity relation; one more distance/value is needed
# for unique numerical velocities.
# If the intended question assumes the cars start from a known distance D:
# u + v = D/1 and u - v = D/3.

D = float(input("Enter the distance between the cars (km): "))

total_speed = D / 1
difference_speed = D / 3

u = (total_speed + difference_speed) / 2
v = (total_speed - difference_speed) / 2

print("Velocity of faster car =", u, "km/h")
print("Velocity of slower car =", v, "km/h")
