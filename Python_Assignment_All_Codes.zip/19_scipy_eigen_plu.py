# Q4(ii). Create a 4x4 matrix and find eigenvalues,
# eigenvectors and PLU decomposition using SciPy.

import numpy as np
from scipy.linalg import eig, lu

A = np.array([
    [4, 1, 2, 0],
    [1, 5, 0, 1],
    [2, 0, 6, 1],
    [0, 1, 1, 7]
], dtype=float)

eigenvalues, eigenvectors = eig(A)

print("Matrix:")
print(A)

print("\nEigenvalues:")
print(eigenvalues)

print("\nEigenvectors:")
print(eigenvectors)

P, L, U = lu(A)

print("\nP matrix:")
print(P)

print("\nL matrix:")
print(L)

print("\nU matrix:")
print(U)
