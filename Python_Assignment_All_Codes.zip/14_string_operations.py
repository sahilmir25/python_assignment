# String operations
text = input("Enter a string: ")

print("Original string:", text)
print("Uppercase:", text.upper())
print("Lowercase:", text.lower())
print("Length:", len(text))
print("Reversed:", text[::-1])
print("Number of characters:", len(text.replace(" ", "")))
