# Student marks using NumPy
# 10 students, find max, min, average and other requested values.

import numpy as np

marks = np.array([
    [50, 85, 80],
    [60, 95, 35],
    [70, 65, 68],
    [85, 55, 65],
    [80, 85, 90]
])

print("Marks:")
print(marks)

print("\nMaximum marks:", np.max(marks))
print("Minimum marks:", np.min(marks))
print("Average marks:", np.mean(marks))

print("\nStudents/rows having marks greater than 80:")
print(marks[np.any(marks > 80, axis=1)])
