# Q6. Define doSum(num) to find the sum of digits and return it
def doSum(num):
    num = abs(num)
    total = 0

    while num > 0:
        total += num % 10
        num //= 10

    return total

n = int(input("Enter a number: "))
print("Sum of digits =", doSum(n))
