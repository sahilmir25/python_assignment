# Employee tuple
employees = (
    ("Amit", "IT", 50000),
    ("Rahul", "HR", 45000),
    ("Priya", "Finance", 55000),
    ("Suman", "IT", 60000),
    ("Riya", "Sales", 48000)
)

print("Employee tuple:")
for employee in employees:
    print(employee)

name = input("Enter employee name to search: ")

found = False
for employee in employees:
    if employee[0].lower() == name.lower():
        print("Employee found:", employee)
        found = True
        break

if not found:
    print("Employee not found")
