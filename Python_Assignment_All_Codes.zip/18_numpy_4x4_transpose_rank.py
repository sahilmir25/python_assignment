# Q4. Create a 4x4 matrix and find transpose and rank using NumPy

import numpy as np

A = np.array([
    [1, 2, 3, 4],
    [5, 6, 7, 8],
    [2, 4, 6, 8],
    [1, 3, 5, 7]
], dtype=float)

print("Matrix:")
print(A)

print("\nTranspose:")
print(A.T)

print("\nRank:")
print(np.linalg.matrix_rank(A))
