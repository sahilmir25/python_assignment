# Triangle classes using inheritance
# Equilateral, Isosceles and Scalene triangles

class Triangle:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    def valid(self):
        return (
            self.a + self.b > self.c and
            self.a + self.c > self.b and
            self.b + self.c > self.a
        )


class Equilateral(Triangle):
    def check(self):
        return self.valid() and self.a == self.b == self.c


class Isosceles(Triangle):
    def check(self):
        return self.valid() and (
            self.a == self.b or self.b == self.c or self.a == self.c
        )


class Scalene(Triangle):
    def check(self):
        return self.valid() and (
            self.a != self.b and self.b != self.c and self.a != self.c
        )


a = float(input("Enter side 1: "))
b = float(input("Enter side 2: "))
c = float(input("Enter side 3: "))

triangle = Triangle(a, b, c)

if not triangle.valid():
    print("Invalid triangle")
elif Equilateral(a, b, c).check():
    print("Equilateral triangle")
elif Isosceles(a, b, c).check():
    print("Isosceles triangle")
elif Scalene(a, b, c).check():
    print("Scalene triangle")
