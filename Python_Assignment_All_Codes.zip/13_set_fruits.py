# Set operations: fruits, summer fruits and winter fruits
fruits = {
    "Apple", "Mango", "Banana", "Orange", "Guava",
    "Grapes", "Watermelon", "Litchi", "Pomegranate", "Papaya"
}

summer_fruits = {
    "Mango", "Watermelon", "Litchi", "Papaya", "Guava"
}

winter_fruits = {
    "Apple", "Orange", "Pomegranate", "Grapes"
}

print("i) All fruits in the three sets:")
print("Fruits:", fruits)
print("Summer fruits:", summer_fruits)
print("Winter fruits:", winter_fruits)

print("\nii) Fruits present in both summer and winter:")
print(summer_fruits & winter_fruits)

print("\niii) Fruits only in summer, not in fruits set:")
print(summer_fruits - fruits)

print("\niv) Fruits present in summer and winter but not in fruits:")
print((summer_fruits & winter_fruits) - fruits)
