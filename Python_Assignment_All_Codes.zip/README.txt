PYTHON ASSIGNMENT - CODES
============================

All programs are separated into .py files.

For NumPy/SciPy programs install:
    pip install numpy scipy

Run any program with:
    python filename.py

Note:
The handwritten image for the car-velocity question does not provide a
numerical distance, so the program asks for the distance. If your teacher
gave a specific distance elsewhere, enter that value.
