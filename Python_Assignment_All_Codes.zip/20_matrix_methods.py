# Q5. Matrix methods: arange(), det() and transpose()
# (Use the required methods from NumPy.)

import numpy as np

A = np.arange(1, 10).reshape(3, 3)

print("Matrix:")
print(A)

print("\nTranspose:")
print(A.transpose())

print("\nDeterminant:")
print(np.linalg.det(A))

print("\narange result:")
print(np.arange(1, 10))
