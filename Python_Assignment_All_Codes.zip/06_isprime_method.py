# Q5. Define isPrime(num) to check whether num is prime
def isPrime(num):
    if num < 2:
        return False

    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False
    return True

n = int(input("Enter a number: "))

if isPrime(n):
    print(n, "is a prime number")
else:
    print(n, "is not a prime number")
