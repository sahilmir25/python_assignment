# Q2. Solve using SciPy:
# 2x + 3y = 8
# 4x + 5y = 14

import numpy as np
from scipy.linalg import solve

A = np.array([
    [2, 3],
    [4, 5]
], dtype=float)

B = np.array([8, 14], dtype=float)

x, y = solve(A, B)

print("x =", x)
print("y =", y)
