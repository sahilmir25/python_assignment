# For loop examples from the assignment
print("0 to 4:")
for i in range(5):
    print(i, end=" ")

print("\n2 to 4:")
for i in range(2, 5):
    print(i, end=" ")

print("\n2 to 100 with step 3:")
for i in range(2, 101, 3):
    print(i, end=" ")
