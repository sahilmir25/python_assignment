# Q1. Create two 3x3 matrices using NumPy.
# i) inverse of matrix A
# ii) determinant of matrix B
# iii) A * inverse(B)

import numpy as np

A = np.array([
    [1, 2, 3],
    [0, 1, 4],
    [5, 6, 0]
], dtype=float)

B = np.array([
    [2, 1, 1],
    [1, 3, 2],
    [1, 0, 1]
], dtype=float)

print("Matrix A:")
print(A)

print("\nMatrix B:")
print(B)

if np.linalg.det(A) != 0:
    print("\nInverse of A:")
    print(np.linalg.inv(A))
else:
    print("\nA has no inverse.")

print("\nDeterminant of B:")
print(np.linalg.det(B))

if np.linalg.det(B) != 0:
    print("\nA * inverse(B):")
    print(A @ np.linalg.inv(B))
else:
    print("\nB has no inverse.")
