# Q7. Define checkArmstrong(num)
def checkArmstrong(num):
    if num < 0:
        return False

    digits = str(num)
    power = len(digits)
    total = sum(int(digit) ** power for digit in digits)

    return total == num

n = int(input("Enter a number: "))

if checkArmstrong(n):
    print(n, "is an Armstrong number")
else:
    print(n, "is not an Armstrong number")
