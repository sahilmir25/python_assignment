# Set example: employee names
# Input a specific employee name and check whether it is present in the tuple/set.

employees = {"Amit", "Rahul", "Priya", "Suman", "Riya"}

name = input("Enter employee name: ")

if name in employees:
    print("Employee is present.")
else:
    print("Employee is not present.")
